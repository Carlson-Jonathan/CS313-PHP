// Set fs module:
var fs = require('fs');

console.log("HELLO WORLD");
